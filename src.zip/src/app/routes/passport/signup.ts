
export interface Signup {
    phone: string;
    email: string;
    shopName: string;
    password: string;
    confirmPassword: string;
    code: string;
}

